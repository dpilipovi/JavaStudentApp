export interface Student {
    jmbag: string;
    numberOfECTS: number;
    tuitionShouldBePaid: boolean
    }